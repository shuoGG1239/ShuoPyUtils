from setuptools import setup

setup(
    name="shuogg",              # 包名
    version="0.1",              # 版本信息
    packages=['shuogg'],        # 要打包的项目文件夹
    description="shuoGG's common utils",
    keywords='python util',
    author='shuoGG',
    author_email='328893769@qq.com',
    url='https://github.com/shuoGG1239/ShuoPyUtils',
    zip_safe=False
)
